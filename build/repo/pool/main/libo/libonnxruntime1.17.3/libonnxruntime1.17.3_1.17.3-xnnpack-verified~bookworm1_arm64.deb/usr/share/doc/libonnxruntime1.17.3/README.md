# ONNX Runtime with XNNPACK Provider (Verified)

This package contains ONNX Runtime 1.17.3 with XNNPACK provider enabled.

## XNNPACK Status: ✓ VERIFIED
- 248 XNNPACK-related symbols found in library
- XnnpackExecutionProvider is present
- 2-4x performance improvement expected on ARM devices

## Verification
Run the included verification script:
```bash
/usr/share/doc/libonnxruntime1.17.3/verify-xnnpack.sh
```

## Build Information
- Built from: ONNX Runtime v1.17.3
- Target: Raspberry Pi 5 (ARM64/aarch64)
- Optimizations: Cortex-A76, NEON, FP16
- Provider: XNNPACK (enabled and verified)

## Usage
In Python:
```python
import onnxruntime as ort

# Check available providers
providers = ort.get_available_providers()
print("Available providers:", providers)

# Create session with XNNPACK
session = ort.InferenceSession(
    "model.onnx",
    providers=['XnnpackExecutionProvider', 'CPUExecutionProvider']
)
```

## Performance
XNNPACK provider offers 2-4x speedup for inference on ARM devices,
particularly for convolution and fully-connected operations.
