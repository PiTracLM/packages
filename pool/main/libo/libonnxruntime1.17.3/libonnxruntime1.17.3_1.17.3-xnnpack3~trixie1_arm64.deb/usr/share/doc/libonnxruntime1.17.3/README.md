# ONNX Runtime 1.17.3 with XNNPACK

This package provides ONNX Runtime with the XNNPACK execution provider
optimized for Raspberry Pi 5 (Cortex-A76).

## Features
- XNNPACK execution provider for 2-4x faster inference on ARM
- Optimized for YOLOv8/v11 single object detection models
- Built with Pi5 optimization flags: -march=armv8.2-a+fp16+dotprod -mtune=cortex-a76

## Verification
Run: /usr/share/doc/libonnxruntime1.17.3/verify-xnnpack.sh

## Python Test
python3 -c "import onnxruntime; print(onnxruntime.get_available_providers())"

Built for PiTrac project.
