#!/bin/bash
# Verify XNNPACK is properly included in ONNX Runtime
LIB=$(find /usr/lib -name "libonnxruntime.so*" -type f 2>/dev/null | head -1)
if [ -z "$LIB" ]; then
    echo "ERROR: libonnxruntime.so not found"
    exit 1
fi
COUNT=$(strings "$LIB" | grep -ci xnnpack || true)
if [ "$COUNT" -gt 0 ]; then
    echo "✓ XNNPACK VERIFIED: Found $COUNT XNNPACK symbols in $LIB"
    exit 0
else
    echo "✗ XNNPACK NOT FOUND in $LIB"
    exit 1
fi
